<!DOCTYPE html>
<!--halaman view -->
<div id="page-wrapper" class="well">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header ">Berita Terbaru</h1>
            <blockquote contenteditable="false">
                <p> Selamat ada login sebagai <strong style="color:#1BBC9B">Panitia</strong> mentoring di e-mentoring ikhsan mentoring
                </p> <small><?php echo date('D, d - m - Y ')?>, e-men</small>
            </blockquote>    

        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <!-- halaman view -->
   
    <!-- modal logout dilanjutkan di footer-->