<?php

$this->load->view('templates_pengajar/header');
$this->load->view('templates_pengajar/sidebar');

$this->load->view($view);
$this->load->view('templates_pengajar/footer');    