

<!--bagian dalam konten-->
<footer> 
    <br><br><br><br><br><br><br><hr> 
    <p>&copy; DKM's Research 2014</p>
</footer>


        <!-- jQuery Version 1.11.0 -->
        <script src="<?php echo base_url('aset/js/jquery-1.11.0.js')?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url('aset/js/bootstrap.min.js')?>"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo base_url('aset/js/plugins/metisMenu/metisMenu.min.js')?>"></script>

        <!-- Morris Charts JavaScript -->
        <script src="<?php echo base_url('aset/js/plugins/morris/raphael.min.js')?>"></script>
        <script src="<?php echo base_url('aset/js/plugins/morris/morris.min.js')?>"></script>
        <script src="<?php echo base_url('aset/js/plugins/morris/morris-data.js')?>"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo base_url('aset/js/sb-admin-2.js')?>"></script>

    </body>

</html>


