<?php

$this->load->view('templates_peserta/header');
$this->load->view('templates_peserta/sidebar');

$this->load->view($view);
$this->load->view('templates_peserta/footer');
