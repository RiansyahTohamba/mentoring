
<!--awal konten-->
<div id="page-wrapper">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default mar lengkung">
                <h3 class="panel-heading">
                    Informasi Terbaru Mengenai Mentoring
                </h3>
                <div class="panel-body">
                    <div class="well">
                        Assalamualaikum pementor, <?php echo $this->session->userdata('NAMA') ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!--akhir konten-->
