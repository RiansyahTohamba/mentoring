<!--awal konten-->
<div id="page-wrapper">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default mar lengkung">
                <h3 class="panel-heading">
                    Catatan
                </h3> <br>
                    <div class="row">
                      <div class="col-md-1"></div>
                      <div class="col-md-5">
                          <div class="form-group">
                            <label>Judul</label>
                            <input class="form-control" name="pertemuan" type="text" value="" >
                          </div>
                      </div>
                      <div class="col-md-5">
                          <div class="form-group">
                            <label>Kepada</label>
                           <select name ="id_materi" class="form-control">
                              <option value="aa"> </option>
                            </select>
                          </div>
                        
                           <div class="col-md-1"></div>

                      </div>
                    </div>
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-10">
                            <div class="form-group">
                            <label>Berita Acara</label>
                            <textarea class="form-control" name="berita"></textarea>
                            </div>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                     <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-10">
                           
                            <button class="btn btn-success" data-toggle="modal" data-target=".bs-example-modal-lg"><span class="glyphicon glyphicon-cog"> Kirim </span></button> 
                            <br><br><br>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
            </div>

        </div>
    </div>
</div>
</div>
<!--akhir konten-->
