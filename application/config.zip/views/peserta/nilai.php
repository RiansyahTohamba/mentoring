<div class="page-header">
    <h3>nilai peserta mentoring</h3>
</div>
<table class="table table-striped">
    <tr>
        <th>Nilai</th>
        <th>Skor</th>

    </tr>
<?php echo $nilai;?>
</table>
