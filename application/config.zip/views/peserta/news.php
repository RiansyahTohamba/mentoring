<!-- halaman view -->
<div class="page-header">
    <h3>informasi terbaru mengenai mentoring</h3>
</div>
<blockquote contenteditable="true">
    <p> Selamat ada login sebagai <strong style="color:#1BBC9B">Peserta</strong> mentoring di e-mentoring ikhsan mentoring, pada 19 Juni 2014
    </p> <small><?php echo date('D, d - m - y'); ?>, e-men</small>
</blockquote>    
<?php if ($status_side_bar == FALSE) { ?>

    <p> <h3> Isi no hp,jenis kelamin,password terlebih dahulu ! klik
        <a href="<?php echo base_url('peserta/editawal'); ?>"> 
            disini
        </a>
    </h3>
    </p> 

<?php } ?>

<!--persiapan untuk mematikan semua fitur kecuali kontak telah diisi-->

