<div class="page-header">
    <h3>profile peserta mentoring</h3>
</div>

<?php echo $data_profil;?>

<a class="btn btn-primary" href="<?php echo site_url('peserta/profile/editprofile')?>">
    <i class="glyphicon glyphicon-edit"></i> Edit Profile
</a>


