<div class="page-header">
    <h3>Absensi peserta mentoring</h3>
</div>
<table class="table table-striped">    
    <tr>
        <th>Pertemuan</th> <th>Keterangan</th>
        <th>Pementor</th> <th>Tanggal</th>
        <th>Detil pertemuan</th> 
    </tr>
    <?php echo $presensi; ?>
</table>
