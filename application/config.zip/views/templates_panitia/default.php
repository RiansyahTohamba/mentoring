<?php

$this->load->view('templates_panitia/header');
$this->load->view('templates_panitia/sidebar');

$this->load->view($view);
$this->load->view('templates_panitia/footer');
